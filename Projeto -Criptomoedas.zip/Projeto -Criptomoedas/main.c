#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <time.h>

typedef struct {
    float reais;
    float bitcoin;
    float ethereum;
    float ripple;
} Carteira;

typedef struct {
    char cpf[12];      
    char senha[7];     
    char nome[50];     
    Carteira carteira;
} Investidor;

typedef struct {
    float bitcoin;
    float ethereum;
    float ripple;
} Cotacoes;

#define TAXA_BTC_COMPRA 0.02f
#define TAXA_BTC_VENDA  0.03f
#define TAXA_ETH_COMPRA 0.01f
#define TAXA_ETH_VENDA  0.02f
#define TAXA_XRP_COMPRA 0.01f
#define TAXA_XRP_VENDA  0.01f

void carregarCotacoes(Cotacoes *c);
void salvarCotacoes(Cotacoes c);
int carregarInvestidor(const char *cpfBusca, Investidor *inv);
void salvarInvestidor(Investidor inv);
void registrarExtrato(const char *cpf, const char *tipo, float cotacao, float taxa, Investidor inv);
void obterDataHora(char *buffer);

void consultarSaldo(Investidor inv);
void consultarExtrato(Investidor inv);
void depositarReais(Investidor *inv);
void sacarReais(Investidor *inv);
void comprarCripto(Investidor *inv);
void venderCripto(Investidor *inv);
void atualizarCotacoes();
void menuInvestidor(Investidor *inv);

void obterDataHora(char *buffer) {
    time_t t = time(NULL);
    struct tm tm = *localtime(&t);
    sprintf(buffer, "%02d-%02d-%04d %02d:%02d",
           tm.tm_mday, tm.tm_mon + 1, tm.tm_year + 1900,
           tm.tm_hour, tm.tm_min);
}

void carregarCotacoes(Cotacoes *c) {
    FILE *f = fopen("cotacoes.txt", "r");
    if (f == NULL) {
        c->bitcoin = 350000.0f;
        c->ethereum = 18000.0f;
        c->ripple = 3.50f;
        salvarCotacoes(*c);
        return;
    }
    fscanf(f, "%f %f %f", &c->bitcoin, &c->ethereum, &c->ripple);
    fclose(f);
}

void salvarCotacoes(Cotacoes c) {
    FILE *f = fopen("cotacoes.txt", "w");
    if (f != NULL) {
        fprintf(f, "%.2f %.2f %.2f\n", c.bitcoin, c.ethereum, c.ripple);
        fclose(f);
    }
}

int carregarInvestidor(const char *cpfBusca, Investidor *inv) {
    FILE *f = fopen("investidores.txt", "r");
    if (f == NULL) return 0;

    char nomeArq[50];
    while (fscanf(f, "%s %s %s %f %f %f %f",
                  inv->cpf, inv->senha, nomeArq,
                  &inv->carteira.reais, &inv->carteira.bitcoin,
                  &inv->carteira.ethereum, &inv->carteira.ripple) == 7) {
        
        for (int i = 0; nomeArq[i] != '\0'; i++) {
            if (nomeArq[i] == '_') nomeArq[i] = ' ';
        }
        strcpy(inv->nome, nomeArq);

        if (strcmp(inv->cpf, cpfBusca) == 0) {
            fclose(f);
            return 1; 
        }
    }
    fclose(f);
    return 0;
}

void salvarInvestidor(Investidor inv) {
    char nomeTratado[50];
    strcpy(nomeTratado, inv.nome);
    for (int i = 0; nomeTratado[i] != '\0'; i++) {
        if (nomeTratado[i] == ' ') nomeTratado[i] = '_';
    }

    FILE *f = fopen("investidores.txt", "r");
    FILE *temp = fopen("temp.txt", "w");
    int encontrado = 0;

    char cpfLido[12], senhaLida[7], nomeLido[50];
    float r, b, e, x;

    if (f != NULL) {
        while (fscanf(f, "%s %s %s %f %f %f %f", cpfLido, senhaLida, nomeLido, &r, &b, &e, &x) == 7) {
            if (strcmp(cpfLido, inv.cpf) == 0) {
                fprintf(temp, "%s %s %s %.2f %.4f %.4f %.4f\n",
                        inv.cpf, inv.senha, nomeTratado,
                        inv.carteira.reais, inv.carteira.bitcoin,
                        inv.carteira.ethereum, inv.carteira.ripple);
                encontrado = 1;
            } else {
                fprintf(temp, "%s %s %s %.2f %.4f %.4f %.4f\n",
                        cpfLido, senhaLida, nomeLido, r, b, e, x);
            }
        }
        fclose(f);
    }

    if (!encontrado) {
        fprintf(temp, "%s %s %s %.2f %.4f %.4f %.4f\n",
                inv.cpf, inv.senha, nomeTratado,
                inv.carteira.reais, inv.carteira.bitcoin,
                inv.carteira.ethereum, inv.carteira.ripple);
    }

    if (temp != NULL) {
        fclose(temp);
    }

    remove("investidores.txt");
    rename("temp.txt", "investidores.txt");
}

void registrarExtrato(const char *cpf, const char *tipo, float cotacao, float taxa, Investidor inv) {
    FILE *f = fopen("extrato.txt", "a");
    if (f != NULL) {
        char data[20];
        obterDataHora(data);
        fprintf(f, "%s | %s | %s | CT: %.2f | TX: %.2f | REAL: %.2f | BTC: %.4f | ETH: %.4f | XRP: %.4f\n",
                cpf, data, tipo, cotacao, taxa,
                inv.carteira.reais, inv.carteira.bitcoin, inv.carteira.ethereum, inv.carteira.ripple);
        fclose(f);
    }
}

void consultarSaldo(Investidor inv) {
    char senhaDigitada[7];
    printf("\nDigite sua senha: ");
    scanf("%s", senhaDigitada);

    if (strcmp(inv.senha, senhaDigitada) != 0) {
        printf("Senha incorreta!\n");
        return;
    }

    printf("\n--- SALDO ---\n");
    printf("Nome: %s\n", inv.nome);
    printf("CPF: %s\n", inv.cpf);
    printf("Reais: R$ %.2f\n", inv.carteira.reais);
    printf("Bitcoin: %.4f\n", inv.carteira.bitcoin);
    printf("Ethereum: %.4f\n", inv.carteira.ethereum);
    printf("Ripple: %.4f\n", inv.carteira.ripple);
    printf("-------------\n");
}

void consultarExtrato(Investidor inv) {
    char senhaDigitada[7];
    printf("\nDigite sua senha: ");
    scanf("%s", senhaDigitada);

    if (strcmp(inv.senha, senhaDigitada) != 0) {
        printf("Senha incorreta!\n");
        return;
    }

    FILE *f = fopen("extrato.txt", "r");
    if (f == NULL) {
        printf("\nSem extratos.\n");
        return;
    }

    printf("\n--- EXTRATO ---\n");
    char linha[300];
    int achou = 0;
    while (fgets(linha, sizeof(linha), f) != NULL) {
        if (strncmp(linha, inv.cpf, 11) == 0) {
            printf("%s", linha);
            achou = 1;
        }
    }
    fclose(f);

    if (!achou) {
        printf("Nenhuma transacao.\n");
    }
    printf("---------------\n");
}

void depositarReais(Investidor *inv) {
    float valor;
    printf("\nValor para depositar (R$): ");
    scanf("%f", &valor);

    if (valor <= 0) {
        printf("Valor invalido!\n");
        return;
    }

    inv->carteira.reais += valor;
    salvarInvestidor(*inv);

    char desc[40];
    sprintf(desc, "+ %.2f REAL", valor);
    registrarExtrato(inv->cpf, desc, 0.0f, 0.0f, *inv);

    printf("Deposito OK! Saldo atual: R$ %.2f\n", inv->carteira.reais);
}

void sacarReais(Investidor *inv) {
    float valor;
    printf("\nValor para sacar (R$): ");
    scanf("%f", &valor);

    if (valor <= 0 || valor > inv->carteira.reais) {
        printf("Saldo insuficiente ou valor invalido!\n");
        return;
    }

    inv->carteira.reais -= valor;
    salvarInvestidor(*inv);

    char desc[40];
    sprintf(desc, "- %.2f REAL", valor);
    registrarExtrato(inv->cpf, desc, 0.0f, 0.0f, *inv);

    printf("Saque OK! Saldo atual: R$ %.2f\n", inv->carteira.reais);
}

void comprarCripto(Investidor *inv) {
    char senhaDigitada[7];
    printf("\nDigite sua senha: ");
    scanf("%s", senhaDigitada);

    if (strcmp(inv->senha, senhaDigitada) != 0) {
        printf("Senha incorreta!\n");
        return;
    }

    Cotacoes cot;
    carregarCotacoes(&cot);

    printf("\n1. BTC - R$ %.2f\n", cot.bitcoin);
    printf("2. ETH - R$ %.2f\n", cot.ethereum);
    printf("3. XRP - R$ %.2f\n", cot.ripple);

    int op;
    printf("Escolha (1-3): ");
    scanf("%d", &op);

    float valorReais;
    printf("Quanto quer investir (R$): ");
    scanf("%f", &valorReais);

    if (valorReais <= 0 || valorReais > inv->carteira.reais) {
        printf("Saldo insuficiente!\n");
        return;
    }

    float qtd = 0, taxa = 0;
    char desc[40];

    if (op == 1) {
        taxa = valorReais * TAXA_BTC_COMPRA;
        qtd = (valorReais - taxa) / cot.bitcoin;
        inv->carteira.reais -= valorReais;
        inv->carteira.bitcoin += qtd;
        sprintf(desc, "+ %.4f BTC", qtd);
        registrarExtrato(inv->cpf, desc, cot.bitcoin, taxa, *inv);
    } else if (op == 2) {
        taxa = valorReais * TAXA_ETH_COMPRA;
        qtd = (valorReais - taxa) / cot.ethereum;
        inv->carteira.reais -= valorReais;
        inv->carteira.ethereum += qtd;
        sprintf(desc, "+ %.4f ETH", qtd);
        registrarExtrato(inv->cpf, desc, cot.ethereum, taxa, *inv);
    } else if (op == 3) {
        taxa = valorReais * TAXA_XRP_COMPRA;
        qtd = (valorReais - taxa) / cot.ripple;
        inv->carteira.reais -= valorReais;
        inv->carteira.ripple += qtd;
        sprintf(desc, "+ %.4f XRP", qtd);
        registrarExtrato(inv->cpf, desc, cot.ripple, taxa, *inv);
    } else {
        printf("Opcao invalida!\n");
        return;
    }

    salvarInvestidor(*inv);
    printf("Compra feita com sucesso!\n");
}

void venderCripto(Investidor *inv) {
    char senhaDigitada[7];
    printf("\nDigite sua senha: ");
    scanf("%s", senhaDigitada);

    if (strcmp(inv->senha, senhaDigitada) != 0) {
        printf("Senha incorreta!\n");
        return;
    }

    Cotacoes cot;
    carregarCotacoes(&cot);

    printf("\n1. BTC\n2. ETH\n3. XRP\n");
    int op;
    printf("Escolha para vender (1-3): ");
    scanf("%d", &op);

    float qtdVenda;
    printf("Quantidade: ");
    scanf("%f", &qtdVenda);

    float bruto = 0, taxa = 0;
    char desc[40];

    if (op == 1) {
        if (qtdVenda <= 0 || qtdVenda > inv->carteira.bitcoin) {
            printf("Saldo insuficiente!\n");
            return;
        }
        bruto = qtdVenda * cot.bitcoin;
        taxa = bruto * TAXA_BTC_VENDA;
        inv->carteira.bitcoin -= qtdVenda;
        inv->carteira.reais += (bruto - taxa);
        sprintf(desc, "- %.4f BTC", qtdVenda);
        registrarExtrato(inv->cpf, desc, cot.bitcoin, taxa, *inv);
    } else if (op == 2) {
        if (qtdVenda <= 0 || qtdVenda > inv->carteira.ethereum) {
            printf("Saldo insuficiente!\n");
            return;
        }
        bruto = qtdVenda * cot.ethereum;
        taxa = bruto * TAXA_ETH_VENDA;
        inv->carteira.ethereum -= qtdVenda;
        inv->carteira.reais += (bruto - taxa);
        sprintf(desc, "- %.4f ETH", qtdVenda);
        registrarExtrato(inv->cpf, desc, cot.ethereum, taxa, *inv);
    } else if (op == 3) {
        if (qtdVenda <= 0 || qtdVenda > inv->carteira.ripple) {
            printf("Saldo insuficiente!\n");
            return;
        }
        bruto = qtdVenda * cot.ripple;
        taxa = bruto * TAXA_XRP_VENDA;
        inv->carteira.ripple -= qtdVenda;
        inv->carteira.reais += (bruto - taxa);
        sprintf(desc, "- %.4f XRP", qtdVenda);
        registrarExtrato(inv->cpf, desc, cot.ripple, taxa, *inv);
    } else {
        printf("Opcao invalida!\n");
        return;
    }

    salvarInvestidor(*inv);
    printf("Venda feita com sucesso!\n");
}

void atualizarCotacoes() {
    Cotacoes cot;
    carregarCotacoes(&cot);

    srand(time(NULL));
    float varBtc = (((float)rand() / RAND_MAX) * 0.10f) - 0.05f;
    float varEth = (((float)rand() / RAND_MAX) * 0.10f) - 0.05f;
    float varXrp = (((float)rand() / RAND_MAX) * 0.10f) - 0.05f;

    cot.bitcoin += cot.bitcoin * varBtc;
    cot.ethereum += cot.ethereum * varEth;
    cot.ripple += cot.ripple * varXrp;

    salvarCotacoes(cot);

    printf("\nCotacoes atualizadas!\n");
    printf("BTC: R$ %.2f | ETH: R$ %.2f | XRP: R$ %.2f\n", cot.bitcoin, cot.ethereum, cot.ripple);
}

void menuInvestidor(Investidor *inv) {
    int op;
    do {
        printf("\n--- MENU ---\n");
        printf("1. Saldo\n");
        printf("2. Extrato\n");
        printf("3. Depositar\n");
        printf("4. Sacar\n");
        printf("5. Comprar Cripto\n");
        printf("6. Vender Cripto\n");
        printf("7. Atualizar Cotacoes\n");
        printf("8. Logout\n");
        printf("Opcao: ");
        scanf("%d", &op);

        switch (op) {
            case 1: consultarSaldo(*inv); break;
            case 2: consultarExtrato(*inv); break;
            case 3: depositarReais(inv); break;
            case 4: sacarReais(inv); break;
            case 5: comprarCripto(inv); break;
            case 6: venderCripto(inv); break;
            case 7: atualizarCotacoes(); break;
            case 8: printf("Saindo da conta...\n"); break;
            default: printf("Opcao invalida!\n");
        }
    } while (op != 8);
}

int main() {
    int opcao;
    do {
        printf("\n=== EXCHANGE ===\n");
        printf("1. Login\n");
        printf("2. Sair\n");
        printf("Opcao: ");
        scanf("%d", &opcao);

        if (opcao == 1) {
            char cpf[12];
            printf("CPF (so numeros): ");
            scanf("%s", cpf);

            Investidor inv;
            if (carregarInvestidor(cpf, &inv)) {
                printf("Bem-vindo de volta, %s\n", inv.nome);
                menuInvestidor(&inv);
            } else {
                printf("CPF nao cadastrado. Deseja cadastrar? (1-Sim / 2-Nao): ");
                int resp;
                scanf("%d", &resp);
                if (resp == 1) {
                    strcpy(inv.cpf, cpf);
                    printf("Senha (6 digitos): ");
                    scanf("%s", inv.senha);
                    printf("Nome completo: ");
                    getchar(); 
                    fgets(inv.nome, sizeof(inv.nome), stdin);
                    inv.nome[strcspn(inv.nome, "\n")] = 0; 

                    inv.carteira.reais = 0.0f;
                    inv.carteira.bitcoin = 0.0f;
                    inv.carteira.ethereum = 0.0f;
                    inv.carteira.ripple = 0.0f;

                    salvarInvestidor(inv);
                    printf("Cadastrado! Entrando...\n");
                    menuInvestidor(&inv);
                }
            }
        }
    } while (opcao != 2);

    return 0;
}