#include <stdio.h>
#include <stdlib.h>

float potencia(float x, int n) {

	int contador;
	float resultado = 1;
	
	for (contador = 1; contador <= n; contador ++){
		resultado = resultado * x;
		}
		return resultado;
	}


int main(){
	float base;
	int exp;
	float result;
	scanf("%f", &base);
	scanf("%d", &exp);
	result = potencia(base, exp);
	printf("%f\n", result);


	system("pause");	
	return 0;
}
