#include <stdio.h>
#include <math.h> // Necess�rio para a fun��o sqrt()

// Fun��o para calcular a hipotenusa
float calcular_hipotenusa(float a, float b) {
    return sqrt((a * a) + (b * b));
}

// Fun��o para ler um lado do usu�rio
float ler_lado(int numero_lado) {
    float valor;
    printf("Digite o %d� lado mais curto (cateto): ", numero_lado);
    scanf("%f", &valor); // No float usamos %f no lugar de %lf

    while (valor <= 0) {
        printf("Por favor, digite um valor maior que zero: ");
        scanf("%f", &valor);
    }

    return valor;
}

// Fun��o para exibir o resultado
void exibir_resultado(float resultado) {
    printf("\nA hipotenusa do tri�ngulo �: %.2f\n", resultado);
}

int main() {
    float cateto1, cateto2, hipotenusa;

    printf("--- Calculadora de Hipotenusa ---\n");

    cateto1 = ler_lado(1);
    cateto2 = ler_lado(2);

    hipotenusa = calcular_hipotenusa(cateto1, cateto2);

    exibir_resultado(hipotenusa);

    return 0;
}
