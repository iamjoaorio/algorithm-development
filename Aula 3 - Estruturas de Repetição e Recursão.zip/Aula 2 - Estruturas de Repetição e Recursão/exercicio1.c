#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

int main() {

    setlocale(LC_ALL, "Portuguese");

    int contador;
    float numero;
    float soma = 0;
    float media;

    for (contador = 1; contador <= 5; contador++) {

        printf("Digite o %d numero: ", contador);
        scanf("%f", &numero);

        soma = soma + numero;
    }

    media = soma / 5;

    printf("\nA soma dos numeros e: %.2f\n", soma);
    printf("A media e: %.2f\n", media);

    system("pause");
    return 0;
}
