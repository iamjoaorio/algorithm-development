#include <stdio.h>
#include <stdlib.h>
#include <locale.h>

/* Faca um programa que imprima os n�meros de 1 a 50 de 1 em 1 e
de 52 a 100 de 2 em 2. */

int main() {

    setlocale(LC_ALL, "Portuguese");

    int i;

    for(i = 1; i <= 50; i++) {
        printf("%d\n", i);
    }

    for(i = 52; i <= 100; i = i + 2) {
        printf("%d\n", i);
    }

    system("pause");
    return 0;
}
