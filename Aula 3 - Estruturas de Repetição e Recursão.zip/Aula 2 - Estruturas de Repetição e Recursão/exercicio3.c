#include <stdio.h>

int main() {
    int numero, maior;
    int i; // Declarada fora do for

    for (i = 1; i <= 6; i++) {
        printf("Digite o %d� n�mero: ", i);
        scanf("%d", &numero);

        if (i == 1 || numero > maior) {
            maior = numero;
        }
    }

    printf("\nO maior n�mero digitado foi: %d\n", maior);
    return 0;
}
