#include <stdio.h>
#include <stdlib.h>

/* Fa�a um programa para receber um vetor de 10 elementos (pedir
para o usu�rio) e apresentar: a soma dos ELEMENTOS pares e a
soma dos elementos de �NDICE par. */

int main() {
    int numeros[10];
    int somaElemento, somaIndice;
    int i;

    for (i = 0; i < 10; i++) {
        printf("Digite um numero: \n");
        scanf("%d", &numeros[i]);
    }

    somaElemento = 0;
    somaIndice = 0;

    for (i = 0; i < 10; i++) {
        if (i % 2 == 0) {
            somaIndice = somaIndice + numeros[i];
        }
    }

    for (i = 0; i < 10; i++) {
        if (numeros[i] % 2 == 0) {
            somaElemento = somaElemento + numeros[i];
        }
    }

    printf("A soma dos ELEMENTOS pares �: %d\n", somaElemento);
    printf("A soma dos INDICES pares �: %d\n", somaIndice);

    system("pause");
    return 0;
}

