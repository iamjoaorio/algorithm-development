#include <stdio.h>
#include <stdlib.h>
#include <locale.h>
#include <time.h>

/* Fa�a um programa que cria uma matriz 10x15, sendo que cada
elemento � um inteiro gerado aleatoriamente. Ent�o, exiba a
matriz completa e, na sequ�ncia, somente os elementos da
primeira coluna da matriz. */

int main() {
    setlocale(LC_ALL, "Portuguese");
    srand(time(NULL));

    int matriz[10][15];
    int linha, coluna;

    // Preenchendo a matriz
    for (linha = 0; linha < 10; linha++) {
        for (coluna = 0; coluna < 15; coluna++) {
            matriz[linha][coluna] = rand() %100;
        }
    }

    // Exibindo a matriz completa
    for (linha = 0; linha < 10; linha++) {
        for (coluna = 0; coluna < 15; coluna++) {
            printf("[%5d]", matriz[linha][coluna]);
        }
        printf("\n");
    }

    // Exibindo a primeira coluna
    printf("\nPrimeira coluna:\n");

    for (linha = 0; linha < 10; linha++) {
        printf("[%d]\n", matriz[linha][0]);
    }

    system("pause");
    return 0;
}

