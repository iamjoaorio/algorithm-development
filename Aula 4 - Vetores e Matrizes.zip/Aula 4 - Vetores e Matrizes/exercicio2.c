#include <stdio.h>
#include <stdlib.h>

/* Fa�a um programa que imprime uma sequ�ncia de 5 n�meros
em ordem inversa � da leitura. */

int main() {

    int numeros[5];
    int i;

    for (i = 0; i < 5; i++) {
        printf("Digite um numero: \n");
        scanf("%d", &numeros[i]);
    }

    for (i = 4; i >= 0; i--) {
        printf("Inversa: %d\n", numeros[i]);
    }

    system("pause");
    return 0;
}
