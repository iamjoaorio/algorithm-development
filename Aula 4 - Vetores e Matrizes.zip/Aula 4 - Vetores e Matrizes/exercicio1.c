#include <stdio.h>
#include <stdlib.h>

/* Crie um programa em C que pe�a 10 n�meros reais, armazene-os
em um vetor e diga qual � o �ndice do maior, e seu valor. */

int main() {

    float lista[10];
    int index;
    int maior;

    for (index = 0; index < 10; index++) {
        printf("Digite um numero real: ");
        scanf("%f", &lista[index]);
    }

    maior = 0;

    for (index = 0; index < 10; index++) {
        if (lista[index] > lista[maior]) {
            maior = index;
        }
    }

    printf("Maior numero: %.2f\n", lista[maior]);
    printf("Indice do maior: %d\n", maior);

    system("pause");
    return 0;
}
